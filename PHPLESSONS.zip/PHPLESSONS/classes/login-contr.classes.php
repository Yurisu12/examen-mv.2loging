<?php

class loginContr extends Login
{
    //Private to make these properties least accesable
    private $uid;
    private $pwd;


    //assining user input to there properties in here
    public function __construct($uid, $pwd,)
    {
        $this->uid = $uid;
        $this->pwd = $pwd;
    }

    //this fuyction is for errors handler
    public function loginUser()
    {
        if ($this->emptyInput() == false) {
            // echo "Empty input!";
            header("location: index.php?error=emptyinput");
            exit();
        }

        // als er geen error komt. Wordt de user aangemaakt bij de database. linked to signup-database.php
        $this->getUser($this->uid, $this->pwd,);
    }


    //checking if user put empty input
    private function emptyInput()
    {
        $result;
        if (empty($this->ud) || empty($this->pwd)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

}