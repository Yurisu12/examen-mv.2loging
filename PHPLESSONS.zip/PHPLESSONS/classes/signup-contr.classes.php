<?php

class SignupContr extends Signup
{
    //Private to make these properties least accesable
    private $userid;
    private $pwd;
    private $pwdrepeat;
    private $email;

    //assing user input to there properties in here
    public function __construct($userid, $pwd, $pwdrepeat, $email)
    {
        $this->userid = $userid;
        $this->pwd = $pwd;
        $this->pwdrepeat = $pwdrepeat;
        $this->email = $email;
    }

    //this fuyction is for errors handler
    public function signupUser()
    {
        if ($this->emptyInput() == false) {
            // echo "Empty input!";
            header("location: index.php?error=emptyinput");
            exit();
        }

        if ($this->invalidEmail() == false) {
            // echo "Invalid Email!";
            header("location: index.php?error=email");
            exit();
        }

        if ($this->pwdMatch() == false) {
            // echo "Password doesn't match!";
            header("location: index.php?error=passwordmatch");
            exit();
        }

        if ($this->useridTaken() == false) {
            // echo "Username or email taken!";
            header("location: index.php?error=usernameoremailtaken");
            exit();
        }

        // als er geen error komt. Wordt de user aangemaakt bij de database. linked to signup-database.php
        $this->setUser($this->uid, $this->pwd, $this->email);
    }


    //checking if user put empty input
    private function emptyInput()
    {
        $result;
        if (empty($this->uid) || empty($this->pwd) || empty($this->pwdrepeat) || empty($this->email)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

    //to check for right type of email adress
    private function invalidEmail()
    {
        $result;
        if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

    //to chech if its the same password
    private function pwdMatch()
    {
        $result;
        if ($this->pwd !== $this->pwdrepeat) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

    //TO check if the uid and email is already taken
    private function useridTaken()
    {
        $result;
        if (!$this->checkUser($this->uid, $this->email)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }
}
