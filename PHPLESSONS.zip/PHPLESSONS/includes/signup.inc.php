<?php

//Check if we have submit button set
if(isset($_POST["submit"])) {

    //Grabbing the data
    $uid = $_POST["uid"];
    $pwd = $_POST["pwd"];
    $pwdrepeat = $_POST["pwdrepeat"];
    $email = $_POST["email"];

    //Instantiate SingupContr class
    include "../classes/dbh.classes.php";
    include "../classes/signup.classes.php";
    include "../classes/signup-contr.classes.php";
    $signup = new SignupContr($uid, $pwd, $pwdrepeat, $email);
    //Running error handlers and user singup
    $signup->signupUser();

    //Going to back to front page
    header("location: ../index.php?error=none");
}



?>