<?php

session_start(); //start session
session_unset();  //to unset all difference session variables
session_destroy(); //destroy current session 

    //Going to back to front page
    header("location: ../index.php?error=none");
